package com.mc.util.collection.list;

import com.mc.util.collection.list.mc.McLinkedListTest;

public class Run {

	public static void main(String[] args) {
		//new _List().studyList();
		new McLinkedListTest().studyList();
	}

}
